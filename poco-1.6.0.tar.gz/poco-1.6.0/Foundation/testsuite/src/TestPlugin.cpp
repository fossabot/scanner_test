//
// TestPlugin.cpp
//
// $Id: //poco/1.4/Foundation/testsuite/src/TestPlugin.cpp#1 $
//
// Copyright (c) 2004-2006, Applied Informatics Software Engineering GmbH.
// and Contributors.
//
// SPDX-License-Identifier:	BSL-1.0
//


#include "TestPlugin.h"


TestPlugin::TestPlugin()
{
}


TestPlugin::~TestPlugin()
{
}
