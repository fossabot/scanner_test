$Id: README.txt 50 2007-01-08 12:16:50Z mloskot $
-------------------------------------------------------------------------------
WCELIBCEX - Windows CE C Library Extensions
-------------------------------------------------------------------------------

The WCELIBCEX is a package of C library extensions for Windows CE
operating system. It is a supplement to standard C library
available on Windows CE system.

Project developer: Mateusz Loskot <mateusz@loskot.net>

Homepage: http://sourceforge.net/projects/wcelibcex
Wiki: http://wcelibcex.sourceforge.net

For details, check following files:
AUTHORS.txt - list of developers and contributors
LICENSE.txt - license agreement
COPYING.txt - copyright and provenience notice
BUILD.txt   - building instructions

Initial version of WCELIBCEX was founded and copyrighted by Taxus SI Ltd.,
http://www.taxussi.com.pl 
