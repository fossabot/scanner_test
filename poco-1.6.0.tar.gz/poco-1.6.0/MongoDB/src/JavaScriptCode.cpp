//
// JavaScriptCode.cpp
//
// $Id$
//
// Library: MongoDB
// Package: MongoDB
// Module:  JavaScriptCode
//
// Implementation of the JavaScriptCode class.
//
// Copyright (c) 2012, Applied Informatics Software Engineering GmbH.
// and Contributors.
//
// SPDX-License-Identifier:	BSL-1.0
//


#include "Poco/MongoDB/JavaScriptCode.h"


namespace Poco {
namespace MongoDB {


JavaScriptCode::JavaScriptCode()
{

}


JavaScriptCode::~JavaScriptCode()
{
}


} } // namespace Poco::MongoDB
